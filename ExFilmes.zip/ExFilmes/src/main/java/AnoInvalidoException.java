public class AnoInvalidoException extends Exception {
    public AnoInvalidoException() {
        super();
    }
    public AnoInvalidoException(String msg) {
        super(msg);
    }
}
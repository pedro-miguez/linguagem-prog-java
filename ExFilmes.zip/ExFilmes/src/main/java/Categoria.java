public enum Categoria {
    COMEDIA, ACAO, TERROR, THRILLER, DRAMA, ANIMACAO
}

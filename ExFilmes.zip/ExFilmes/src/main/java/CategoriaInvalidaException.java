public class CategoriaInvalidaException extends Exception {
    public CategoriaInvalidaException() {
        super();
    }
    public CategoriaInvalidaException(String msg) {
        super(msg);
    }
}
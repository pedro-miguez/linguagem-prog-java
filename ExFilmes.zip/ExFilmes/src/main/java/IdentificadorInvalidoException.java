public class IdentificadorInvalidoException extends Exception {
    public IdentificadorInvalidoException() {
        super();
    }
    public IdentificadorInvalidoException(String msg) {
        super(msg);
    }
}